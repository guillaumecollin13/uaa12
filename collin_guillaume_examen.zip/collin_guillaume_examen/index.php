<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>acceuil</title>
    <link rel="stylesheet" href="css/cssexamen.css">
</head>
<body>
    <li class="edensflex lol justifycontentspacearound ">
        <ul class="aie">
        <a href="index.php" class="edenstext ">accueil</a>
        </ul>
        <ul class="aie">
        <a href="fonction.php"class="edenstext ">fonction</a>
        </ul>
        <ul class="aie">
          <a  href="*"class="edenstext ">contact</a>
        </ul>
    </li>
    <div class="edensflex backgroundcolor1 edenspad">
    <div class="coloneimage">
    <div>
        <img src="image/image_1exam.png" alt="symbole de fairytail bleu">
        <img src="image/image_1exam.png" alt="symbole de fairytail bleu">
    </div>
    <div>
        <img src="image/image_1exam.png" alt="symbole de fairytail bleu">
        <img src="image/image_1exam.png" alt="symbole de fairytail bleu">
    </div>
    <div>
        <img src="image/image_1exam.png" alt="symbole de fairytail bleu">
        <img src="image/image_1exam.png" alt="symbole de fairytail bleu">
    </div>
    <div>
        <img src="image/image_2exam.png" alt="symbole hunter">
        <img src="image/image_2exam.png" alt="symbole hunter">
    </div>
    <div>
        <img src="image/image_2exam.png" alt="symbole hunter">
        <img src="image/image_2exam.png" alt="symbole hunter">
    </div>
    <div>
        <img src="image/image_3exam.jfif" alt="symbole owlhouse">
        <img src="image/image_3exam.jfif" alt="symbole owlhouse">
    </div>
    <div>
        <img src="image/image_3exam.jfif" alt="symbole owlhouse">
        <img src="image/image_3exam.jfif" alt="symbole owlhouse">
    </div>
    <div>
        <img src="image/image_3exam.jfif" alt="symbole owlhouse">
        <img src="image/image_3exam.jfif" alt="symbole owlhouse">
    </div>
    <div>
        <img src="image/image_4exam.png" alt="goblin from mars">
        <img src="image/image_4exam.png" alt="goblin from mars">
    </div>
    <div>
        <img src="image/image_4exam.png" alt="goblin from mars">
        <img src="image/image_4exam.png" alt="goblin from mars">
    </div>
    <div>
        <img src="image/image_4exam.png" alt="goblin from mars">
        <img src="image/image_4exam.png" alt="goblin from mars">
    </div>
    </div>
    <div class=" justifycontentspaceevenly formulaire edensflex ">
        <div>
        <fieldset class="largform paddfield">
            <legend class="color edenstext">vos information</legend>
            <div>
            <label class="titreforms "> votre nom </label>
            <input type="text" name="nom" id="nom">
            </div>
           <div>
           <label class="titreforms ">votre prenom</label>
            <input type="text" name="prenom" id="prenom">
           </div>
            <div>
            <label class="titreforms ">votre email</label>
            <input type="email" name="mail" id="mail"> 
            </div>
            <div>
                <label class="titreforms ">votre numéro de telephone</label>
                <input type="phone" name="numtel" id="numtel">
            </div>
        </fieldset>
        </div>
        <div>
        <fieldset class="largform">
            <legend class="color edenstext">votre commande</legend>
                <div>
                    <label class="titreforms ">chosissez parmi les possibilité</label>
                    <select name="possibillité" id="possibillité">
                        <optgroup label="hardware">Hardware</optgroup>
                            <option value="ecran">écran</option>
                            <option value="souris">souris</option>
                            <option value="clavier">clavier</option>
                            <option value="ram">ram</option>
                            <option value="Disque_dur">Disque dur</option>
                        <optgroup label="software">software</optgroup>
                            <option value="office365">office 365</option>
                            <option value="pakettracer">paket tracer</option>
                            <option value="googleworkspace">google workspace</option>
                    </select>
                </div>
                <div>
                <label class="titreforms">quantite desire</label>
                    <select name="quntite" id="quantite">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                    </select>
                </div>
                <div class="titreforms">
                    <label>date de commande souhaite</label>
                    <input type="date" name="date" id="date">
                </div>
                <div>
                    <label>factures choisie</label>
                    <div>
                        <input type="checkbox" name="mail" id="mail">
                        <label>par mail</label>
                    </div>
                    <div>
                         <input type="checkbox" name="papier" id="papier">
                         <label>par papier</label>
                    </div>
                </div>
                <div>
                    <label class="titreforms">remarques suplémentaire</label>
                    <input type="message" name="message" id="message">
                </div>
            
        </fieldset>
        </div>
    </div>
    <div class="coloneimage">
    <div>
        <img src="image/image_1exam.png" alt="symbole de fairytail bleu">
        <img src="image/image_1exam.png" alt="symbole de fairytail bleu">
    </div>
    <div>
        <img src="image/image_1exam.png" alt="symbole de fairytail bleu">
        <img src="image/image_1exam.png" alt="symbole de fairytail bleu">
    </div>
    <div>
        <img src="image/image_1exam.png" alt="symbole de fairytail bleu">
        <img src="image/image_1exam.png" alt="symbole de fairytail bleu">
    </div>
    <div>
        <img src="image/image_2exam.png" alt="symbole hunter">
        <img src="image/image_2exam.png" alt="symbole hunter">
    </div>
    <div>
        <img src="image/image_2exam.png" alt="symbole hunter">
        <img src="image/image_2exam.png" alt="symbole hunter">
    </div>
    <div>
        <img src="image/image_3exam.jfif" alt="symbole owlhouse">
        <img src="image/image_3exam.jfif" alt="symbole owlhouse">
    </div>
    <div>
        <img src="image/image_3exam.jfif" alt="symbole owlhouse">
        <img src="image/image_3exam.jfif" alt="symbole owlhouse">
    </div>
    <div>
        <img src="image/image_3exam.jfif" alt="symbole owlhouse">
        <img src="image/image_3exam.jfif" alt="symbole owlhouse">
    </div>
    <div>
        <img src="image/image_4exam.png" alt="goblin from mars">
        <img src="image/image_4exam.png" alt="goblin from mars">
    </div>
    <div>
        <img src="image/image_4exam.png" alt="goblin from mars">
        <img src="image/image_4exam.png" alt="goblin from mars">
    </div>
    <div>
        <img src="image/image_4exam.png" alt="goblin from mars">
        <img src="image/image_4exam.png" alt="goblin from mars">
    </div>
    </div>
    </div>
   <div class="edensflex justifycontentspacebetween">
   <div></div>
    <div class="button">
        <input class="button lol border" type="submit" >
    </div>
    <div></div>
   </div>
    <div class="lol">
    <li class="edensflex lol justifycontentspacebetween ">
        <p class="aie">examen 2022-2023</br>Uaa12 : creation d'un site web dynamique</p>
        </ul>
        <ul>
          <p class="aie">5tti</p>
        </ul>
    </li>
    </div>

</body>
</html>